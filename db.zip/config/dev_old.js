// dev.js - don't commit this!!!
module.exports = {
  mongoURI: 'mongodb://localhost:27017/nbf',
  cookieKey: 'jhdalkhaklsjdhjlakshdjkhskjdhjadlkhsdlkjas',
  jwtSecret: 'somethingsecret',
  jwtExpiresIn: '8h',
  jwtCookieExpiresIn: 8,
  environment: 'development'
};