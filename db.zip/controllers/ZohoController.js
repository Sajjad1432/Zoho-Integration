const { default: axios } = require('axios');
const FormData = require('form-data');


async function createZohoAccount(formData) {


    const token = await generateToken();

    var data = JSON.stringify({
        "data": [{
            "Account_Name": formData.username,
            "Email": formData.email,
            "Account_Type" : 'Client'
        }]
    });

    var config = {
        method: 'post',
        url: 'https://www.zohoapis.com/crm/v3/Accounts',
        headers: {
            'Authorization': 'Zoho-oauthtoken '+token,
            'Content-Type': 'application/json',
        },
        data: data
    };

    const account = await axios(config)
        .then(function (response) {
            return response.data;
        })
        .catch(function (error) {
            console.log(error);
            throw error;
            // throw error.data.message;
        });

    return account;

}


async function updateZohoAccount(formData) {


    const token = await generateToken();

    var data = JSON.stringify({
        "data": [{
            "Owner" : formData.username,
            "Account_Name": formData.username,
            "Phone" : "0300-1234567",
            "Billing_Street" : "BIII 1901/16 New Satellite Town",
            "Email": formData.email,
            "Account_Type" : 'Client'
        }]
    });

    var config = {
        method: 'put',
        url: 'https://www.zohoapis.com/crm/v3/Accounts/',
        headers: {
            'Authorization': 'Zoho-oauthtoken '+token,
            'Content-Type': 'application/json',
        },
        data: data
    };

    const account = await axios(config)
        .then(function (response) {
            return response.data;
        })
        .catch(function (error) {
            console.log(error);
            throw error;
            // throw error.data.message;
        });

    return account;

}


async function createZohoContact(formData) {

    const token = await generateToken();

    var data = JSON.stringify({
        "data": [{
            "Owner": formData.username,
            "Lead_Source" : "Registration Form",
            "Full_Name": formData.username,
            "Last_Name": formData.username,
            "Email": formData.email,
            "Tag": formData.subscriptionPlanId
        }]
    });

    var config = {
        method: 'post',
        url: 'https://www.zohoapis.com/crm/v3/Contacts',
        headers: {
            'Authorization': 'Zoho-oauthtoken '+token,
            'Content-Type': 'application/json',
        },
        data: data
    };

    const account = await axios(config)
        .then(function (response) {
            return response.data;
        })
        .catch(function (error) {
            throw error;
        });


    return account;

}

async function createZohoTask(formData) {

    const token = await generateToken();

    console.log(token);

    var data = JSON.stringify({
        "data": [{
            "Description": "Hello World!",
            "Status": "Not Started",
            "Due_Date": "2022-08-06",
            "Subject": "My Task Subject",
        }]
    });

    var config = {
        method: 'post',
        url: 'https://www.zohoapis.com/crm/v3/Tasks',
        headers: {
            'Authorization': 'Zoho-oauthtoken '+token,
            'Content-Type': 'application/json',
        },
        data: data
    };

    const account = await axios(config)
        .then(function (response) {
            return response.data;
        })
        .catch(function (error) {
            console.log(error);
            throw error;
        });


    return account;

}


async function generateToken(){

    //Access Token Generated From Refresh Token (Not Expire)
    // return '1000.48424f6412cb48b337bf15d520df7d5e.10f5e64c5b1de21bdbbbd17581abd4ab';
    var data = new FormData();
    data.append('client_id', '1000.I7MP2CQBXQSTWLO8LYG31TXCAARX3X');
    data.append('client_secret', '1e4a35398c526b40dd1750b66bed08af787219ab56');
    data.append('refresh_token', '1000.49ccc2e8e459f86cc1a28751718c6ac3.981190e67ebd5806941a3bb6397b84c7');
    data.append('grant_type', 'refresh_token');

    // var data = JSON.stringify({
    //     "client_id": '1000.I7MP2CQBXQSTWLO8LYG31TXCAARX3X',
    //     "client_secret": '1e4a35398c526b40dd1750b66bed08af787219ab56',
    //     "refresh_token": '1000.49ccc2e8e459f86cc1a28751718c6ac3.981190e67ebd5806941a3bb6397b84c7',
    //     "grant_type": 'refresh_token',
    // });

    var config = {
        method: 'post',
        url: 'https://accounts.zoho.com/oauth/v2/token',
        data: data
    };


    const refreshToken = await axios(config)
        .then(function (response) {
            console.log("Refresh Token");
            if(response.data.error)
                throw response.data.error;

            if(response.data.access_token)
            {
                const token = response.data.access_token;
                return token;
            }
        })
        .catch(function (error) {
            console.log("ERROR---------->",error);
            throw error;
        });

    return refreshToken;
}

module.exports = {
    createZohoAccount,
    createZohoContact,
    createZohoTask
}