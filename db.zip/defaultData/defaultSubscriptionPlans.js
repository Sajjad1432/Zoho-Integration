const subscriptionPlans = [
  { title: 'Ala Carte', price: 0, recurringPeriod: 'monthly' },
  { title: 'Standard', price: 29, recurringPeriod: 'monthly' },
  { title: 'Complete', price: 59, recurringPeriod: 'monthly' }
]

module.exports = subscriptionPlans;