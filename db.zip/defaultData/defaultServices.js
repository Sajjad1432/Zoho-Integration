const services = [
  { title: 'Register Limited Liability Company', type: 'register'},
  { title: 'Register Proprietorship/Patnership', type: 'register'},
  { title: 'Register Coporation', type: 'register'},
  { title: 'Register Non-Profit Corporation', type: 'register'},
  { title: 'Register Trade Name/DBA', type: 'register'},
  { title: 'Apply for File Federal Tax ID', type: 'manage'},
  { title: 'Operating Agreement', type: 'manage'},
  { title: 'Renew LLC or Corporation', type: 'manage'},
  { title: 'Renew Trade Name', type: 'manage'},
  { title: 'Trade Name / DBA', type: 'manage'},
  { title: 'Amend Business Information', type: 'manage'},
]

module.exports = services;