const rates = [
  { title: 'Resource 1', link: 'http://www.kasfjsdfs.com/referal' }
]

module.exports = rates;